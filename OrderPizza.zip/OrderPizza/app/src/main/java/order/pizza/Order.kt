package order.pizza

import java.io.Serializable

class Order : Serializable {
    var pizzaType: String = ""
    var topping: String = ""
    var extraCheese: String = ""
    var includeDelivery: String = ""
    var specialInstructions: String = ""
    var name: String = ""
    var address: String = ""
    var phone: String = ""
    var email: String = ""
    var totalPrice: Double = 0.0
}