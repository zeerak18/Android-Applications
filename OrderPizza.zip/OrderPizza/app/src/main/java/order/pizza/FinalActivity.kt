package order.pizza

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_final.*
import java.lang.StringBuilder

class FinalActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_final)

        intent.extras?.getSerializable("order")?.let {
            val order = it as Order
            val stringBuilder = StringBuilder("Your Order")
            stringBuilder.append("\n")
            stringBuilder.append("\n")
            stringBuilder.append(order.pizzaType)
            stringBuilder.append("\n")
            stringBuilder.append(order.topping)
            stringBuilder.append("\n")
            stringBuilder.append(order.extraCheese)
            stringBuilder.append("\n")
            stringBuilder.append("\n")
            stringBuilder.append(order.specialInstructions)
            stringBuilder.append("\n")
            stringBuilder.append(order.includeDelivery + "" + order.address)
            stringBuilder.append("\n")
            stringBuilder.append(order.name)
            stringBuilder.append("\n")
            stringBuilder.append(order.phone)
            stringBuilder.append("\n")
            stringBuilder.append(order.email)
            stringBuilder.append("\n")
            stringBuilder.append("\n")
            stringBuilder.append("Total price of your order : $".plus(String.format("%.2f", order.totalPrice)))
            tvSummary.text = stringBuilder.toString()
        }

        btnNewOrder.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
        }
    }

}