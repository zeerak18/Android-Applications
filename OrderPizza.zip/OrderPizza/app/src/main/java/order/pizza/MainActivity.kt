package order.pizza

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.CompoundButton
import android.widget.RadioGroup
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    var finalOrder: Order = Order()
    var totalPrice: Double = 0.0

    val values = arrayOf(
        "Select Topping",
        "Mushrooms ($5)",
        "Tuna ($5)",
        "Sun Dried Tomatoes ($5)",
        "Ground beef ($8)",
        "Shrimps ($10)",
        "Chicken ($7)",
        "Broccoli ($8)",
        "Pineapple ($5)",
        "Steak ($9)",
        "Avocado ($5)"

    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        groupradio.setOnCheckedChangeListener { radioGroup: RadioGroup, i: Int ->
            calculateTotalPrice()
        }

        cbIncludeDelivery.setOnCheckedChangeListener { compoundButton: CompoundButton, b: Boolean ->
            calculateTotalPrice()
        }

        cbExtraCheese.setOnCheckedChangeListener { compoundButton: CompoundButton, b: Boolean ->
            calculateTotalPrice()
        }

        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {
            }

            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                calculateTotalPrice()
            }

        }

        ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            values
        ).also {
            it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            spinner.adapter = it
        }

        btnSubmit.setOnClickListener {
            finalOrder.name = "Name: ".plus(etName.text.toString())
            finalOrder.address = etAddress.text.toString()
            finalOrder.email = "Email: ".plus(etEmail.text.toString())
            finalOrder.phone = "Phone: ".plus(etPhone.text.toString())
            finalOrder.specialInstructions =
                "Instructions: ".plus(etSpecialInstructions.text.toString())

            val intent = Intent(this, FinalActivity::class.java)
            intent.putExtra("order", finalOrder)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
        }

    }

    fun calculateTotalPrice() {
        totalPrice = 0.0
        totalPrice += addPizzaSelectionPrice()
        totalPrice += addToppingPrice()
        totalPrice += addExtraCheese()
        totalPrice += includeDeliveryPrice()

        totalPrice.apply {
            tvTotalPrice.text = "Total price: ".plus(String.format("%.2f", this))
            finalOrder.totalPrice = this
        }
    }

    private fun includeDeliveryPrice(): Double {
        return if ((cbIncludeDelivery.isChecked)) {
            finalOrder.includeDelivery = "delivery to: "
            5.0
        } else {
            finalOrder.includeDelivery = ""
            0.0
        }
    }

    private fun addExtraCheese(): Double {
        return if (cbExtraCheese.isChecked) {
            finalOrder.extraCheese = "with extra cheese"
            5.0
        } else {
            finalOrder.extraCheese = ""
            0.0
        }
    }

    private fun addToppingPrice(): Double {
        spinner.selectedItemPosition.apply {

            if (this > 0) {
                finalOrder.topping = "Topping: ".plus(values[this])
            } else {
                finalOrder.topping = ""
            }

            return when (this) {
                1 -> 5.0
                2 -> 5.0
                3 -> 7.0
                4 -> 8.0
                5 -> 10.0
                6 -> 5.0
                7 -> 9.0
                8 -> 5.0
                9 -> 5.0
                10 -> 8.0
                else -> 0.0
            }
        }
    }

    private fun addPizzaSelectionPrice(): Double {

        groupradio.checkedRadioButtonId.apply {
            return when (this) {
                R.id.radio_one -> {
                    finalOrder.pizzaType = "Round pizza 6 slices - serves 3 people"
                    5.5
                }
                R.id.radio_two -> {
                    finalOrder.pizzaType = "Round pizza 8 slices - serves 4 people"
                    7.99
                }
                R.id.radio_three -> {
                    finalOrder.pizzaType = "Round pizza 10 slices - serves 5 people"
                    9.50
                }
                R.id.radio_four -> {
                    finalOrder.pizzaType = "Round pizza 12 slices - serves 6 people"
                    11.38
                }
                else -> 0.0
            }
        }
    }

}
